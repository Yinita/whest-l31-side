# Phase 1 private re-evaluation nominations — LOCKED

Per forum [#18125](https://discourse.aicrowd.com/t/18125): nominate **up to two** graded Phase-1 submissions for private re-evaluation.

## Locked pair (do not change unless organizers require otherwise)

| Priority | Submission | Adj score | Estimator |
|----------|------------|-----------|-----------|
| **1** | **[#325459](https://www.aicrowd.com/challenges/arc-white-box-estimation-challenge-2026/submissions/325459)** | 3.202e-07 | `pure-0.2.1s` (current evaluator) |
| **2** | **[#325112](https://www.aicrowd.com/challenges/arc-white-box-estimation-challenge-2026/submissions/325112)** | 3.202e-07 | same estimator |

**Explicitly excluded:** residual-pack, util/gain Mini↑online↓ IDs, moment-chain code (not shipped / not competitive on adj).

When organizers email nomination instructions, reply with exactly these two IDs.

---

## Algorithmic Contribution (矩链轴)

| Item | Path |
|------|------|
| Write-up (md) | [`phase1_algo_contribution.md`](phase1_algo_contribution.md) |
| Write-up (pdf) | [`phase1_algo_contribution.pdf`](phase1_algo_contribution.pdf) |
| Forum / email copy | [`POSTING_DRAFTS.md`](POSTING_DRAFTS.md) |
| Checklist | [`SUBMIT_CHECKLIST.md`](SUBMIT_CHECKLIST.md) |
| Zip package | [`phase1_algo_contribution_325459.zip`](phase1_algo_contribution_325459.zip) |

- **Write-up ↔ submission ID:** **#325459** only (organizer 1:1 rule)  
- **Intellectual axis:** trajectory-calibrated moment chain (#314695 replication + our ledger), measured against #325459 sampling frontier  
- **Due:** **17 August 2026, 23:59 UTC**  
- **Channels:** forum post *or* `arc-whestbench@aicrowd.com`  
- **No more Phase-1 submission burns** for this track
