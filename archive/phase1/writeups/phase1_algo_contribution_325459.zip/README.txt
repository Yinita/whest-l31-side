Phase 1 Algorithmic Contribution — submission #325459

Axis: trajectory-calibrated moment chain (#314695 replication) vs Hadamard sampling frontier.

Nominations (private re-eval): #325459, #325112
Write-up due: 17 Aug 2026 23:59 UTC
Email: arc-whestbench@aicrowd.com  OR  Challenge Discussion forum

Files:
  phase1_algo_contribution.pdf
  PHASE1_NOMINATIONS.md
  bias_var_mini20_v010.json
  moment_chain_eval_mini_gate.json
  dagger_mini_meanonly_meta.json
